import {errors} from 'appium/driver.js';

import type {AndroidUiautomator2Driver} from '../driver.js';
import {APK_EXTENSION} from '../extensions.js';
import type {InstallOptions} from './types.js';

/**
 * Installs multiple APKs with `install-multiple` option.
 * @param apks - Array of APK file paths or URLs to install.
 * @param options - Optional installation options (allowTestPackages, useSdcard, grantPermissions, etc.).
 * @throws {errors.InvalidArgumentError} If the apks array is empty or invalid.
 */
export async function mobileInstallMultipleApks(
  this: AndroidUiautomator2Driver,
  apks: string[],
  options?: InstallOptions,
): Promise<void> {
  if (!Array.isArray(apks) || apks.length === 0) {
    throw new errors.InvalidArgumentError('No apks are given to install');
  }
  const configuredApks = await Promise.all(apks.map((app) => this.helpers.configureApp(app, [APK_EXTENSION])));
  await this.adb.installMultipleApks(configuredApks, options);
}
